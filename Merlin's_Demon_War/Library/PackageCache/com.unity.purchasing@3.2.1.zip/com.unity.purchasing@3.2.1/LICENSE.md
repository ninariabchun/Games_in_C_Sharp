Unity IAP copyright © 2021 Unity Technologies SF

Your use of the Unity Technologies SF ("Unity') services known as "Unity IAP" are subject to the Unity Monetization Services Terms of Service linked to and copied immediately below.

[Unity Monetization Services TOS](https://unity3d.com/legal/monetization-services-terms-of-service)

Your use of Unity IAP constitutes your acceptance of such terms. Unless expressly provided otherwise, the software under this license is made available strictly on an "AS IS" BASIS WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. Please review the license for details on these and other terms and conditions.


*****************************************************************
Google Play Billing Library v3.0.3 © 2021 Google, LLC


Google Play Billing Library v3.0.3 is made available pursuant to the Android Software Development Kit License linked to immediately below:

[Android Software Development Kit License](https://developer.android.com/studio/terms.html)
