﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("UnityEditor.Purchasing.EditorTests")]
[assembly:InternalsVisibleTo("Unity.IntegrationTests")]
[assembly:InternalsVisibleTo("Unity.RuntimeTests")]

