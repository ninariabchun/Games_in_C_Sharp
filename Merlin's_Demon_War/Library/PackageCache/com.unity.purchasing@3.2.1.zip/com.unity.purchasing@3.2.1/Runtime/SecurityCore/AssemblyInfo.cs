﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("UnityEngine.Purchasing.Security")]
[assembly:InternalsVisibleTo("UnityEngine.Purchasing.SecurityStub")]
[assembly:InternalsVisibleTo("specs")]
