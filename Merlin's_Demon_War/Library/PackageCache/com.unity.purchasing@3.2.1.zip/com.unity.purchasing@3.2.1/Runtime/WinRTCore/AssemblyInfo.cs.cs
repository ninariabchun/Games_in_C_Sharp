﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UnityEngine.Purchasing.WinRT")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.WinRTStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Stores")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.RuntimeTests")]
