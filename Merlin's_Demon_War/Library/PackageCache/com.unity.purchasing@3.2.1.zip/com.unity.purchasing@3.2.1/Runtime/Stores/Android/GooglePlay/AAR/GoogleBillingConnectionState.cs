namespace UnityEngine.Purchasing
{
    enum GoogleBillingConnectionState
    {
        Disconnected,
        Connecting,
        Connected
    }
}
