namespace UnityEngine.Purchasing.Interfaces
{
    interface IGooglePurchaseUpdatedListener { }
}
