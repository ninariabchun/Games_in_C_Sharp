
namespace UnityEngine.Purchasing
{
    interface IGooglePlayStorePurchaseService
    {
        void Purchase(ProductDefinition product);
    }
}
