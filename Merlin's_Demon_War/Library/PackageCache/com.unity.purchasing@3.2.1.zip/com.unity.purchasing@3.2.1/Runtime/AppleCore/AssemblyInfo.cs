﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Apple")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleMacos")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleMacosStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Stores")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.RuntimeTests")]
