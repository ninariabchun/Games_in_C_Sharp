using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UnityEditor.Purchasing")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Stores")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Apple")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleCore")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleMacos")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleMacosStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.AppleStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.Security")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.SecurityStub")]
[assembly: InternalsVisibleTo("UnityEngine.Purchasing.RuntimeTests")]
