using System;

namespace UnityEditor.Timeline
{
    interface IMenuName
    {
        string menuName { get; }
    }
}
